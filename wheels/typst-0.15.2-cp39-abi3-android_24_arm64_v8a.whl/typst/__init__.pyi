import datetime
import pathlib
from types import EllipsisType
from typing import List, Optional, TypeVar, overload, Dict, Union, Literal, Tuple

Input = TypeVar("Input", str, pathlib.Path, bytes)
OutputFormat = Literal["pdf", "svg", "png", "html"]
PathLike = TypeVar("PathLike", str, pathlib.Path)
CreationTimestamp = Union[int, datetime.datetime]
PDFStandard = Literal[
    "1.4",
    "1.5",
    "1.6",
    "1.7",
    "2.0",
    "a-1a",
    "a-1b",
    "a-2a",
    "a-2b",
    "a-2u",
    "a-3a",
    "a-3b",
    "a-3u",
    "a-4",
    "a-4e",
    "a-4f",
    "ua-1",
]
PDFStandards = Optional[Union[PDFStandard, List[PDFStandard]]]

class TypstError(RuntimeError):
    """A structured error raised during Typst compilation or querying.

    This exception provides structured access to Typst diagnostics including
    error messages, hints, and stack traces.

    Attributes:
        message (str): The main error message
        diagnostic (str): Diagnostics to help locate and diagnose the error
        hints (list[str]): List of helpful hints for resolving the error
        trace (list[str]): Stack trace information showing error location context
    """

    message: str
    diagnostic: str
    hints: List[str]
    trace: List[str]

    def __init__(
        self,
        message: str,
        diagnostic: str,
        hints: Optional[List[str]] = None,
        trace: Optional[List[str]] = None,
    ) -> None: ...

class TypstWarning(UserWarning):
    """A structured warning raised during Typst compilation.

    This warning provides structured access to Typst warning diagnostics including
    warning messages, hints, and stack traces.

    Attributes:
        message (str): The main warning message
        diagnostic (str): Diagnostics to help locate and diagnose the error
        hints (list[str]): List of helpful hints related to the warning
        trace (list[str]): Stack trace information showing warning location context
    """

    message: str
    diagnostic: str
    hints: List[str]
    trace: List[str]

    def __init__(
        self,
        message: str,
        diagnostic: str,
        hints: Optional[List[str]] = None,
        trace: Optional[List[str]] = None,
    ) -> None: ...

class FontInfo:
    """Immutable information about a single font variant."""

    family: str
    style: str
    weight: int
    stretch: float
    path: Optional[str]
    index: int

class Fonts:
    def __init__(
        self,
        include_system_fonts: bool = True,
        include_embedded_fonts: bool = True,
        font_paths: List[Input] = [],
    ) -> None: ...
    def fonts(self) -> List["FontInfo"]: ...
    def families(self) -> List[str]: ...

class Compiler:
    def __init__(
        self,
        input: Optional[Input] = None,
        root: Optional[PathLike] = None,
        font_paths: Union[Fonts, List[Input]] = [],
        ignore_system_fonts: bool = False,
        sys_inputs: Dict[str, str] = {},
        package_path: Optional[PathLike] = None,
        package_cache_path: Optional[PathLike] = None,
    ) -> None:
        """Initialize a Typst compiler.
        Args:
            input: Optional .typ file bytes or path to project's main .typ file. Defaults to an empty in-memory document when omitted.
            root (Optional[PathLike], optional): Root path for the Typst project.
            font_paths (Union[Fonts, List[Input]]): Folders with fonts.
            ignore_system_fonts (bool): Ignore system fonts.
            sys_inputs (Dict[str, str]): string key-value pairs to be passed to the document via sys.inputs
            package_path (Optional[PathLike]): Path to load local packages from.
            package_cache_path (Optional[PathLike]): Path to load and cache downloaded packages from.
        """

    def compile(
        self,
        input: Optional[Input] = None,
        output: Optional[Input] = None,
        format: Optional[OutputFormat] = None,
        ppi: Optional[float] = None,
        sys_inputs: Union[EllipsisType, None, Dict[str, str]] = ...,
        pdf_standards: PDFStandards = [],
        root: Optional[PathLike] = None,
        timestamp: Optional[CreationTimestamp] = None,
        pretty: bool = False,
        pdf_tags: bool = True,
    ) -> Optional[Union[bytes, List[bytes]]]:
        """Compile a Typst project.
        Args:
            input: Optional .typ file bytes or path to compile for this invocation.
            output (Optional[PathLike], optional): Path to save the compiled file.
            Allowed extensions are `.pdf`, `.svg`, `.png`, and `.html`
            format (Optional[str]): Output format.
            Allowed values are `pdf`, `svg`, `png`, and `html`.
            ppi (Optional[float]): Pixels per inch for PNG output, defaults to 144.
            sys_inputs: string key-value pairs to be passed to the document via sys.inputs.
                - Ellipsis (default): Keep existing sys_inputs from initialization or previous compile.
                - None: Clear sys_inputs (equivalent to empty dictionary).
                - Dict[str, str]: Use the provided dictionary as sys_inputs.
            pdf_standards (PDFStandards): One or more PDF standard profiles to apply when exporting.
            root (Optional[PathLike]): Override the root path for this compilation.
            timestamp (Optional[CreationTimestamp]): Creation timestamp as timezone-aware fixed-offset datetime.datetime or UNIX seconds, equivalent to SOURCE_DATE_EPOCH.
            pretty (bool): Pretty-print PDF, SVG, and HTML output. Ignored for PNG.
            pdf_tags (bool): Write a tagged PDF for accessibility. Pass False to omit tags, equivalent to `--no-pdf-tags`. Cannot be disabled for PDF/A-1a, PDF/A-2a, PDF/A-3a, and PDF/UA-1. Ignored for SVG, PNG, and HTML.
        Returns:
            Optional[Union[bytes, List[bytes]]]: Return the compiled file as `bytes` if output is `None`.
        """

    def watch(
        self,
        output: PathLike,
        format: Optional[OutputFormat] = None,
        ppi: Optional[float] = None,
        pdf_standards: PDFStandards = [],
        timestamp: Optional[CreationTimestamp] = None,
        pretty: bool = False,
        pdf_tags: bool = True,
    ) -> None:
        """Compile this compiler's input to `output` and recompile whenever it or any file it depends on changes.

        Compilation errors are printed to stderr and do not stop watching.
        Runs until interrupted (raises `KeyboardInterrupt` on Ctrl-C).
        Arguments are as for `compile`; `output` must be a file path.
        """

    def compile_with_warnings(
        self,
        input: Optional[Input] = None,
        output: Optional[Input] = None,
        format: Optional[OutputFormat] = None,
        ppi: Optional[float] = None,
        sys_inputs: Union[EllipsisType, None, Dict[str, str]] = ...,
        pdf_standards: PDFStandards = [],
        root: Optional[PathLike] = None,
        timestamp: Optional[CreationTimestamp] = None,
        pretty: bool = False,
        pdf_tags: bool = True,
    ) -> Tuple[Optional[Union[bytes, List[bytes]]], List[TypstWarning]]:
        """Compile a Typst project and return both result and warnings.
        Args:
            input: Optional .typ file bytes or path to compile for this invocation.
            output (Optional[PathLike], optional): Path to save the compiled file.
            Allowed extensions are `.pdf`, `.svg`, `.png`, and `.html`
            format (Optional[str]): Output format.
            Allowed values are `pdf`, `svg`, `png`, and `html`.
            ppi (Optional[float]): Pixels per inch for PNG output, defaults to 144.
            sys_inputs: string key-value pairs to be passed to the document via sys.inputs.
                - Ellipsis (default): Keep existing sys_inputs from initialization or previous compile.
                - None: Clear sys_inputs (equivalent to empty dictionary).
                - Dict[str, str]: Use the provided dictionary as sys_inputs.
            pdf_standards (PDFStandards): One or more PDF standard profiles to apply when exporting.
            root (Optional[PathLike]): Override the root path for this compilation.
            timestamp (Optional[CreationTimestamp]): Creation timestamp as timezone-aware fixed-offset datetime.datetime or UNIX seconds, equivalent to SOURCE_DATE_EPOCH.
            pretty (bool): Pretty-print PDF, SVG, and HTML output. Ignored for PNG.
            pdf_tags (bool): Write a tagged PDF for accessibility. Pass False to omit tags, equivalent to `--no-pdf-tags`. Cannot be disabled for PDF/A-1a, PDF/A-2a, PDF/A-3a, and PDF/UA-1. Ignored for SVG, PNG, and HTML.
        Returns:
            Tuple[Optional[Union[bytes, List[bytes]]], List[TypstWarning]]: Return a tuple of (compiled_data, warnings).
            The first element is the compiled file as `bytes` if output is `None`, otherwise `None`.
            The second element is a list of structured warnings that occurred during compilation.
        """

    def query(
        self,
        selector: str,
        field: Optional[str] = None,
        one: bool = False,
        format: Optional[Literal["json", "yaml"]] = None,
        root: Optional[PathLike] = None,
    ) -> str:
        """Query a Typst document.
        Args:
            selector (str): Typst selector like `<label>`.
            field (Optional[str], optional): Field to query.
            one (bool, optional): Query only one element.
            format (Optional[str]): Output format, `json` or `yaml`.
            root (Optional[PathLike]): Override the root path for this query.
        Returns:
            str: Return the query result.
        """

    def eval(
        self,
        expression: str,
        format: Optional[Literal["json", "yaml"]] = None,
        pretty: bool = False,
        root: Optional[PathLike] = None,
    ) -> str:
        """Evaluate a Typst expression in this document's context.
        Args:
            expression (str): Typst code expression to evaluate.
            format (Optional[str]): Output format, `json` or `yaml`.
            pretty (bool): Pretty-print JSON output.
            root (Optional[PathLike]): Override the root path for this evaluation.
        Returns:
            str: Return the serialized expression result.
        """

@overload
def compile(
    input: Input,
    output: Input,
    root: Optional[Input] = None,
    font_paths: Union[Fonts, List[Input]] = [],
    ignore_system_fonts: bool = False,
    format: Optional[OutputFormat] = None,
    ppi: Optional[float] = None,
    sys_inputs: Dict[str, str] = {},
    pdf_standards: PDFStandards = [],
    package_path: Optional[PathLike] = None,
    timestamp: Optional[CreationTimestamp] = None,
    pretty: bool = False,
    package_cache_path: Optional[PathLike] = None,
    pdf_tags: bool = True,
) -> None: ...
@overload
def compile(
    input: Input,
    output: None = None,
    root: Optional[Input] = None,
    font_paths: Union[Fonts, List[Input]] = [],
    ignore_system_fonts: bool = False,
    format: Optional[OutputFormat] = None,
    ppi: Optional[float] = None,
    sys_inputs: Dict[str, str] = {},
    pdf_standards: PDFStandards = [],
    package_path: Optional[PathLike] = None,
    timestamp: Optional[CreationTimestamp] = None,
    pretty: bool = False,
    package_cache_path: Optional[PathLike] = None,
    pdf_tags: bool = True,
) -> bytes: ...
def compile(
    input: Input,
    output: Optional[Input] = None,
    root: Optional[Input] = None,
    font_paths: Union[Fonts, List[Input]] = [],
    ignore_system_fonts: bool = False,
    format: Optional[OutputFormat] = None,
    ppi: Optional[float] = None,
    sys_inputs: Dict[str, str] = {},
    pdf_standards: PDFStandards = [],
    package_path: Optional[PathLike] = None,
    timestamp: Optional[CreationTimestamp] = None,
    pretty: bool = False,
    package_cache_path: Optional[PathLike] = None,
    pdf_tags: bool = True,
) -> Optional[Union[bytes, List[bytes]]]:
    """Compile a Typst project.
    Args:
        input: .typ file bytes or path to project's main .typ file.
        output (Optional[PathLike], optional): Path to save the compiled file.
        Allowed extensions are `.pdf`, `.svg`, `.png`, and `.html`
        root (Optional[PathLike], optional): Root path for the Typst project.
        font_paths (Union[Fonts, List[Input]]): Folders with fonts.
        ignore_system_fonts (bool): Ignore system fonts
        format (Optional[str]): Output format.
        Allowed values are `pdf`, `svg`, `png`, and `html`.
        ppi (Optional[float]): Pixels per inch for PNG output, defaults to 144.
        sys_inputs (Dict[str, str]): string key-value pairs to be passed to the document via sys.inputs
        pdf_standards (PDFStandards): One or more PDF standard profiles to apply when exporting.
        package_path (Optional[PathLike]): Path to load local packages from.
        timestamp (Optional[CreationTimestamp]): Creation timestamp as timezone-aware fixed-offset datetime.datetime or UNIX seconds, equivalent to SOURCE_DATE_EPOCH.
        pretty (bool): Pretty-print PDF, SVG, and HTML output. Ignored for PNG.
        package_cache_path (Optional[PathLike]): Path to load and cache downloaded packages from.
        pdf_tags (bool): Write a tagged PDF for accessibility. Pass False to omit tags, equivalent to `--no-pdf-tags`. Cannot be disabled for PDF/A-1a, PDF/A-2a, PDF/A-3a, and PDF/UA-1. Ignored for SVG, PNG, and HTML.
    Returns:
        Optional[Union[bytes, List[bytes]]]: Return the compiled file as `bytes` if output is `None`.
    """

@overload
def compile_with_warnings(
    input: Input,
    output: Input,
    root: Optional[Input] = None,
    font_paths: Union[Fonts, List[Input]] = [],
    ignore_system_fonts: bool = False,
    format: Optional[OutputFormat] = None,
    ppi: Optional[float] = None,
    sys_inputs: Dict[str, str] = {},
    pdf_standards: PDFStandards = [],
    package_path: Optional[PathLike] = None,
    timestamp: Optional[CreationTimestamp] = None,
    pretty: bool = False,
    package_cache_path: Optional[PathLike] = None,
    pdf_tags: bool = True,
) -> Tuple[None, List[TypstWarning]]: ...
@overload
def compile_with_warnings(
    input: Input,
    output: None = None,
    root: Optional[Input] = None,
    font_paths: Union[Fonts, List[Input]] = [],
    ignore_system_fonts: bool = False,
    format: Optional[OutputFormat] = None,
    ppi: Optional[float] = None,
    sys_inputs: Dict[str, str] = {},
    pdf_standards: PDFStandards = [],
    package_path: Optional[PathLike] = None,
    timestamp: Optional[CreationTimestamp] = None,
    pretty: bool = False,
    package_cache_path: Optional[PathLike] = None,
    pdf_tags: bool = True,
) -> Tuple[bytes, List[TypstWarning]]: ...
def compile_with_warnings(
    input: Input,
    output: Optional[Input] = None,
    root: Optional[Input] = None,
    font_paths: Union[Fonts, List[Input]] = [],
    ignore_system_fonts: bool = False,
    format: Optional[OutputFormat] = None,
    ppi: Optional[float] = None,
    sys_inputs: Dict[str, str] = {},
    pdf_standards: PDFStandards = [],
    package_path: Optional[PathLike] = None,
    timestamp: Optional[CreationTimestamp] = None,
    pretty: bool = False,
    package_cache_path: Optional[PathLike] = None,
    pdf_tags: bool = True,
) -> Tuple[Optional[Union[bytes, List[bytes]]], List[TypstWarning]]:
    """Compile a Typst project and return warnings.
    Args:
        input: .typ file bytes or path to project's main .typ file.
        output (Optional[PathLike], optional): Path to save the compiled file.
        Allowed extensions are `.pdf`, `.svg`, `.png`, and `.html`
        root (Optional[PathLike], optional): Root path for the Typst project.
        font_paths (Union[Fonts, List[Input]]): Folders with fonts.
        ignore_system_fonts (bool): Ignore system fonts
        format (Optional[str]): Output format.
        Allowed values are `pdf`, `svg`, `png`, and `html`.
        ppi (Optional[float]): Pixels per inch for PNG output, defaults to 144.
        sys_inputs (Dict[str, str]): string key-value pairs to be passed to the document via sys.inputs
        pdf_standards (PDFStandards): One or more PDF standard profiles to apply when exporting.
        package_path (Optional[PathLike]): Path to load local packages from.
        timestamp (Optional[CreationTimestamp]): Creation timestamp as timezone-aware fixed-offset datetime.datetime or UNIX seconds, equivalent to SOURCE_DATE_EPOCH.
        pretty (bool): Pretty-print PDF, SVG, and HTML output. Ignored for PNG.
        package_cache_path (Optional[PathLike]): Path to load and cache downloaded packages from.
        pdf_tags (bool): Write a tagged PDF for accessibility. Pass False to omit tags, equivalent to `--no-pdf-tags`. Cannot be disabled for PDF/A-1a, PDF/A-2a, PDF/A-3a, and PDF/UA-1. Ignored for SVG, PNG, and HTML.
    Returns:
        Optional[Union[bytes, List[bytes]]]: Return the compiled file as `bytes` if output is `None`.
    """

def query(
    input: Input,
    selector: str,
    field: Optional[str] = None,
    one: bool = False,
    format: Optional[Literal["json", "yaml"]] = None,
    root: Optional[Input] = None,
    font_paths: Union[Fonts, List[Input]] = [],
    ignore_system_fonts: bool = False,
    sys_inputs: Dict[str, str] = {},
    package_path: Optional[PathLike] = None,
    package_cache_path: Optional[PathLike] = None,
) -> str:
    """Query a Typst document.
    Args:
        input: .typ file bytes or path to project's main .typ file.
        selector (str): Typst selector like `<label>`.
        field (Optional[str], optional): Field to query.
        one (bool, optional): Query only one element.
        format (Optional[str]): Output format, `json` or `yaml`.
        root (Optional[PathLike], optional): Root path for the Typst project.
        font_paths (Union[Fonts, List[Input]]): Folders with fonts.
        ignore_system_fonts (bool): Ignore system fonts
        sys_inputs (Dict[str, str]): string key-value pairs to be passed to the document via sys.inputs
        package_path (Optional[PathLike]): Path to load local packages from.
        package_cache_path (Optional[PathLike]): Path to load and cache downloaded packages from.
    Returns:
        str: Return the query result.
    """

def eval(
    input: Input,
    expression: str,
    format: Optional[Literal["json", "yaml"]] = None,
    pretty: bool = False,
    root: Optional[Input] = None,
    font_paths: Union[Fonts, List[Input]] = [],
    ignore_system_fonts: bool = False,
    sys_inputs: Dict[str, str] = {},
    package_path: Optional[PathLike] = None,
    package_cache_path: Optional[PathLike] = None,
) -> str:
    """Evaluate a Typst expression.
    Args:
        input: .typ file bytes or path to project's main .typ file.
        expression (str): Typst code expression to evaluate.
        format (Optional[str]): Output format, `json` or `yaml`.
        pretty (bool): Pretty-print JSON output.
        root (Optional[PathLike], optional): Root path for the Typst project.
        font_paths (Union[Fonts, List[Input]]): Folders with fonts.
        ignore_system_fonts (bool): Ignore system fonts
        sys_inputs (Dict[str, str]): string key-value pairs to be passed to the document via sys.inputs
        package_path (Optional[PathLike]): Path to load local packages from.
        package_cache_path (Optional[PathLike]): Path to load and cache downloaded packages from.
    Returns:
        str: Return the serialized expression result.
    """
